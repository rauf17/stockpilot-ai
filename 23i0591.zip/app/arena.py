"""Common boundary; ordinary Arena requests have no chat memory."""
import asyncio
import logging
from time import perf_counter
from app.agent import run_agent
from app.config import settings
from app.models import ArenaResponse

log = logging.getLogger('arena')

async def execute(request, history=None, model='unconfigured', llm=None, session_state=None):
    started = perf_counter()
    request = request.model_copy(deep=True)
    request.arena_config.max_steps = min(request.arena_config.max_steps, settings.max_steps)
    try:
        async with asyncio.timeout(settings.run_timeout_seconds):
            result = await run_agent(request, history or [], model, llm=llm, session_state=session_state)
            result = ArenaResponse.model_validate(result)
    except TimeoutError:
        result = ArenaResponse(
            request_id=request.request_id,
            status='budget_exceeded',
            final_response='The run timed out after reaching maximum allowed execution time budget.',
            stop_reason='time_budget_reached'
        )
    except Exception as exc:
        log.exception("Execution internal error: %s", exc)
        result = ArenaResponse(
            request_id=request.request_id,
            status='failed',
            final_response=f'The run stopped due to an internal error: {str(exc)}',
            stop_reason='internal_error'
        )
    result.metrics.latency_ms = (perf_counter() - started) * 1000
    if len(result.model_dump_json().encode()) > 50000:
        result = ArenaResponse(
            request_id=request.request_id,
            status='failed',
            final_response='Response exceeded the size limit.',
            stop_reason='response_too_large'
        )
    log.info('request=%s status=%s steps=%s', request.request_id, result.status, result.steps)
    return result
